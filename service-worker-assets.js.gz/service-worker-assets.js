self.assetsManifest = {
  "version": "98vMmwEc",
  "assets": [
    {
      "hash": "sha256-9L6O2Ndt3wJ36IIWg3lDYfL/AeZThi/kiWvXJN/dIGk=",
      "url": "RozvrhUniza.styles.css"
    },
    {
      "hash": "sha256-Jga3CUuNfwvpwnsHZxpWURvivrlrEqnUo9XR5EOLYGc=",
      "url": "_framework/ClosedXML.6d8ybop3kc.wasm"
    },
    {
      "hash": "sha256-bN619zkNwVyqGT2tFn5NMXPDIo3OUVaRYMG/tXRtn+A=",
      "url": "_framework/ClosedXML.Parser.kcd8ka7nog.wasm"
    },
    {
      "hash": "sha256-xKqeqIQ1TDUTD1VdIoWdiNLEIGuxWKmTQB3d0S7bLF8=",
      "url": "_framework/DocumentFormat.OpenXml.Framework.w9qjrpieot.wasm"
    },
    {
      "hash": "sha256-CsWxN9Ml/p0K+b8ZdZtDc1MeTw3kcXnta5uvcgYEwFQ=",
      "url": "_framework/DocumentFormat.OpenXml.ym52o96kep.wasm"
    },
    {
      "hash": "sha256-DWrWJf+NGbjj12iqpO+Ufl4YS0bkW1yz6JwjocU15wY=",
      "url": "_framework/ExcelNumberFormat.zkc9yronjy.wasm"
    },
    {
      "hash": "sha256-ZlwZ9WrrjatVtFEwxQzXjMttliopbxZTgZHoVbbMsUc=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.eqvvq8z8m7.wasm"
    },
    {
      "hash": "sha256-1bZXAq7xg/K+UZT3zZxmJHp4UKNJQBP+2ny+/lGkyHo=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.rwpg67y8a3.wasm"
    },
    {
      "hash": "sha256-njY0gqRtiwE3nddyfjy6CNAK5WVgK7G8m6zGpjN8hJU=",
      "url": "_framework/Microsoft.AspNetCore.Components.y7g6rdtaiv.wasm"
    },
    {
      "hash": "sha256-zaHCBrRXAFuOMETGRVpV0g2MyMtc7qajuH+pMRNR2D8=",
      "url": "_framework/Microsoft.Bcl.HashCode.fhc460s73x.wasm"
    },
    {
      "hash": "sha256-3ADlF4CLU1Q+dQbj0MnPVnEJPiA4q4Jv5xxmiGEvBks=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.85u9862gz3.wasm"
    },
    {
      "hash": "sha256-kKMubKJ3c2lATxpoAuoDqMjzQ+a0M6Ym35pK74cMK2o=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.0cm6d8ej68.wasm"
    },
    {
      "hash": "sha256-fN4AyqImDQ+h3H7tFeF4ZSkjIHJ7qWgbKL217x6P53s=",
      "url": "_framework/Microsoft.Extensions.Configuration.cyz6aj3end.wasm"
    },
    {
      "hash": "sha256-vOEd7hoFklcaq4sqkEeKpoKcuXLNFPQPVoT1tDkiV8E=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.4q1w9mpnm0.wasm"
    },
    {
      "hash": "sha256-Sgs1bgmGaF2mv6rWcaihc+x48ZQQAidfzYwZvYX5WJk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.uum8fsrbn4.wasm"
    },
    {
      "hash": "sha256-popOehVNGTqgvhfA2lSicGjVt9GIh0S5UGL16TYC140=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.qcx6vuhv5d.wasm"
    },
    {
      "hash": "sha256-I/euMiwOKn2U2Y1vqcUjYWEG/7zWmvDiTlHAoPLRHQ0=",
      "url": "_framework/Microsoft.Extensions.Logging.p9svcbtg1a.wasm"
    },
    {
      "hash": "sha256-zb8jFz8oWzH9QDCIv6znwkEZEqBZjRrXTb7biON1h4o=",
      "url": "_framework/Microsoft.Extensions.Options.z0tlm9uxjf.wasm"
    },
    {
      "hash": "sha256-WXYpl64HUqc9+prJOz6dOEVvB8PFJhTdfqUMB3ZGRGA=",
      "url": "_framework/Microsoft.Extensions.Primitives.5pxr7nzxwe.wasm"
    },
    {
      "hash": "sha256-ubnFa4Rtxgu4gPe/SRKYk17LxS0CtEOnEoPvT6ITOTo=",
      "url": "_framework/Microsoft.JSInterop.7kva84rxiz.wasm"
    },
    {
      "hash": "sha256-mpyjzA6YBuV9Qx5BUC8YbXP9YjZlM+k7YTVawzXJFgk=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.imfqvv3x5h.wasm"
    },
    {
      "hash": "sha256-cHsLmPL/ZYfNtaqW793aQui9cR4N7JXjHm+xggcoz7w=",
      "url": "_framework/RBush.048ali807d.wasm"
    },
    {
      "hash": "sha256-pV+0E5WMfRK5Bug6aHxDcFWFuiCVSv7O13dKLf7b8ZU=",
      "url": "_framework/RozvrhUniza.ndfa8jgcx8.wasm"
    },
    {
      "hash": "sha256-TYAwAMga8iYHgcD5+CMUwDAmCjtNUbzJJP6/e+Xtl5w=",
      "url": "_framework/SixLabors.Fonts.1ntl3xbxha.wasm"
    },
    {
      "hash": "sha256-v5OJZqDb9MU4k2lXbzJKN8UE/nhCKJWh8DNJ9GsSt0Q=",
      "url": "_framework/System.Buffers.j7bc0wpfa9.wasm"
    },
    {
      "hash": "sha256-aLuCvQ4qzi4t0uYal3kiji7rNFe9Z+46oNRUtKnh4m8=",
      "url": "_framework/System.Collections.0ye3tsae10.wasm"
    },
    {
      "hash": "sha256-4pdfFlUY3UJ44O2J0vybgJnq4M+wTCKzrus8Rk5r4wU=",
      "url": "_framework/System.Collections.Concurrent.2wylwxr0qj.wasm"
    },
    {
      "hash": "sha256-OTKhdSIiq3TTCKr7yaIMuJ11hR3nYI9jauBQLbdaviA=",
      "url": "_framework/System.Collections.Immutable.jda5qcch26.wasm"
    },
    {
      "hash": "sha256-VSA7yRxVQnrkHyrMi9IKsPvmw/tboNM9UwSLaArwD3Q=",
      "url": "_framework/System.Collections.NonGeneric.7t55ru8qzc.wasm"
    },
    {
      "hash": "sha256-ZPiZ94zPvKNNDs7mC336QY/JQl45txiRyqqk/UKt7DQ=",
      "url": "_framework/System.Collections.Specialized.kobd0rv9a1.wasm"
    },
    {
      "hash": "sha256-Hou28NAAK4UiZqbd9OvLXbsTMGxxQh9dQgKucVgc9Ms=",
      "url": "_framework/System.ComponentModel.Primitives.a5mwzwdkps.wasm"
    },
    {
      "hash": "sha256-0gjZVfvUeok/dX8aSod4vDxVonUKvcHZjRlN4O0LFQk=",
      "url": "_framework/System.ComponentModel.TypeConverter.i477t3wft2.wasm"
    },
    {
      "hash": "sha256-FYS7qt46svIrgPqUwlLyoYjMNzVp1hgnohjIyOMI9B0=",
      "url": "_framework/System.ComponentModel.hpcnoz644y.wasm"
    },
    {
      "hash": "sha256-Eb5m+vRhXMHO15+Wgp4fP4YZRl40XZUVZ2Kol06WIRg=",
      "url": "_framework/System.Console.n29wsw7zcm.wasm"
    },
    {
      "hash": "sha256-aqqdc8iESzv30Ozgq5EM/XebUEWGR29uXebYSjNyOUA=",
      "url": "_framework/System.Data.Common.64goa9alzv.wasm"
    },
    {
      "hash": "sha256-icdEv3KA0NYcpgj/tO4DeiEz+I00CQFTM1i34SoLXJk=",
      "url": "_framework/System.Diagnostics.Debug.9k7hbrh1dl.wasm"
    },
    {
      "hash": "sha256-WTIaO9jlWp1gc+GNRs9kw954huS0bEbief4H1pIS9wY=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.dzuuublwen.wasm"
    },
    {
      "hash": "sha256-1dfUPKS3u9Qv9ccJsZjf3FDQg+ZF+NTh/mUzpjbCN6Q=",
      "url": "_framework/System.Diagnostics.Tools.5o3ptzx9az.wasm"
    },
    {
      "hash": "sha256-0iH+PGMtHzvCNWvzw/RGAFjtRq9dRBb+bRCRvdO7Yoo=",
      "url": "_framework/System.Drawing.Primitives.uw9gkhlaey.wasm"
    },
    {
      "hash": "sha256-KHLN20MI/Vq/1ojzfEzP/H3h5pIJ3xq0akplBTxnjOM=",
      "url": "_framework/System.Drawing.wqh0k022v2.wasm"
    },
    {
      "hash": "sha256-OLCCaf+oGFPC/qKf7kZ8zMR0/g/PHKJMvQqJ2n1GJEs=",
      "url": "_framework/System.IO.Compression.412itmyo9g.wasm"
    },
    {
      "hash": "sha256-Qj8qPVapCBJtlGbPCW7jybQp1lSeBeM3hS+t9f8ru1U=",
      "url": "_framework/System.IO.Compression.Brotli.amehbgfj9w.wasm"
    },
    {
      "hash": "sha256-FH4OvEF4B7ILyTwK44gPeyiqXJulKpbAh/yQ/xyt9Qo=",
      "url": "_framework/System.IO.FileSystem.o7kjh06efz.wasm"
    },
    {
      "hash": "sha256-nNiDUQb9iJcI9YDq62Ayt1s34f5dxQBjzsMjAVUSBqI=",
      "url": "_framework/System.IO.Packaging.sctom6k9ln.wasm"
    },
    {
      "hash": "sha256-ltKNH6AL0soduarPfzy6T90WE3rPgr3GhVxWtFvIglk=",
      "url": "_framework/System.IO.Pipelines.mslxeuynkl.wasm"
    },
    {
      "hash": "sha256-m+6STHoY2czBtOClb9cxmemDAB3sKfEBNS5y/uDqw5Q=",
      "url": "_framework/System.Linq.Expressions.l87fzvi1ia.wasm"
    },
    {
      "hash": "sha256-LiqwbQSHxDzgPHJzGXGcjk81onerhm8mFIzZpdU8XLc=",
      "url": "_framework/System.Linq.Parallel.qe4ybs3ert.wasm"
    },
    {
      "hash": "sha256-jeQTMIE5CUFR5oTZ9GK8ewzfUJzqqY3eDA2ZrU/f4rs=",
      "url": "_framework/System.Linq.x73tni7bwb.wasm"
    },
    {
      "hash": "sha256-qPmrAoO1PPUeYXo6eC1O4hi72Lbn/5PhG9gBJ2CMfIY=",
      "url": "_framework/System.Memory.4p6bnrozjy.wasm"
    },
    {
      "hash": "sha256-VzkxeLr3aINZVEFbWwAO1cYOiGyShYI6KxkvU9H2tE0=",
      "url": "_framework/System.Net.Http.b79b6cg30l.wasm"
    },
    {
      "hash": "sha256-rGIYM/g7mFHB4tUKXxzKAMTdeOGYJ8NmnYQ66r9vFwE=",
      "url": "_framework/System.Net.Primitives.0h7y3g6nqf.wasm"
    },
    {
      "hash": "sha256-2yTahiuKD/tugmTUp9FmVvxVhh4ROWbhQT3MKqiWA5U=",
      "url": "_framework/System.Numerics.Vectors.rcxkni8bpw.wasm"
    },
    {
      "hash": "sha256-lVgmUupAD9gigNnTNgWbdV7oQV1J3jZE94aQGWF/pjM=",
      "url": "_framework/System.ObjectModel.t2vhp2ejyg.wasm"
    },
    {
      "hash": "sha256-9bq5PzKK7Kf59uaJZGIdyiabxCnuC/doO9tX5PpVDBM=",
      "url": "_framework/System.Private.CoreLib.fzdlvvrws6.wasm"
    },
    {
      "hash": "sha256-gvYEmiebdEhhjcerSYxXYPbw3nmO8pNgtXGkfiHJA10=",
      "url": "_framework/System.Private.Uri.20k5mrqpis.wasm"
    },
    {
      "hash": "sha256-+UM0t/SgWqGUmu6r16ABtVNGOQHxKYnOyMH7WEvO7dc=",
      "url": "_framework/System.Private.Xml.31ibgv6t41.wasm"
    },
    {
      "hash": "sha256-QVBtYl7ixd6GhqMFnMLVkBqPwYmk6gNobp0YngtR73E=",
      "url": "_framework/System.Private.Xml.Linq.3vid3n7ga0.wasm"
    },
    {
      "hash": "sha256-eyoe5u0hWBUxCuDEop8Tq/REDXsu9PqnI8DnccMdJxo=",
      "url": "_framework/System.Resources.ResourceManager.vbl2ycgtbr.wasm"
    },
    {
      "hash": "sha256-xJJo33tmgrUCXIP/nqJThcknj6Xe3L4Sqr3Hg77gV2s=",
      "url": "_framework/System.Runtime.CompilerServices.Unsafe.g19ko4sbe2.wasm"
    },
    {
      "hash": "sha256-Hc02lU/0HnEWyAk6Mqy4tlVyKlLr1UPHwQ/zcTvAGyI=",
      "url": "_framework/System.Runtime.Extensions.d8n6u97ct0.wasm"
    },
    {
      "hash": "sha256-5X6FWiZE4NSx4s9iNjfVim2lWQpcbVIsorx1vB6lyno=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.f7txb1es0b.wasm"
    },
    {
      "hash": "sha256-73u7rBAzNtAlf+mkv7AD/5C4dqeNLHYcozQCld7krLc=",
      "url": "_framework/System.Runtime.InteropServices.RuntimeInformation.7awauzj5xy.wasm"
    },
    {
      "hash": "sha256-cPCGs4vZhTyhPqh9mVQkj0m+WWmGdImuq9/aws4c8L0=",
      "url": "_framework/System.Runtime.InteropServices.ouseabnv97.wasm"
    },
    {
      "hash": "sha256-K0AYbWnkHL+Fb3phgIs0vm01lJSW0UQyUJxRokZd2JM=",
      "url": "_framework/System.Runtime.Numerics.xx1g6bcffd.wasm"
    },
    {
      "hash": "sha256-aGkFwCK3oshh6nIOREXaySWbwtRH5m9QjZ7upx7N/Sk=",
      "url": "_framework/System.Runtime.kt8j60jrb1.wasm"
    },
    {
      "hash": "sha256-jZBJOxVDLfhAUcRBpAAhDEfreTUz5FGPka2rU52rIhI=",
      "url": "_framework/System.Security.Cryptography.d4vwzerm85.wasm"
    },
    {
      "hash": "sha256-nowVPzdhrYNVwBj7BFC6KceUhojJ5Gz2vZGxT0qFoSA=",
      "url": "_framework/System.Text.Encodings.Web.e8bnsydrha.wasm"
    },
    {
      "hash": "sha256-LOGVqTUbMUZQlKMLQnd4Xr/7OA5gD4XPJygoiLg8zUI=",
      "url": "_framework/System.Text.Json.89uw8esvxj.wasm"
    },
    {
      "hash": "sha256-cxwyKc2qNQzCNT9RVvRE6PrKy79zdKuE5K7Esc/8EU4=",
      "url": "_framework/System.Text.RegularExpressions.91mg0c6sxi.wasm"
    },
    {
      "hash": "sha256-Y59Yyyw4rVbA98Re6hdA9wEWU1j0xujCjKRQGUVbLFM=",
      "url": "_framework/System.Threading.5m0anikg2o.wasm"
    },
    {
      "hash": "sha256-heJjIS0TxXlTOzoQF5/OcGGEsa8zaQLoOJWyssZdj1U=",
      "url": "_framework/System.Web.HttpUtility.h1htfqt019.wasm"
    },
    {
      "hash": "sha256-yo+J3RWIIHIiwAhqsR9JizNkH/+hd3auB44RBmvvLoI=",
      "url": "_framework/System.Xml.Linq.qsgzs1hc1j.wasm"
    },
    {
      "hash": "sha256-hkGLo/MuT/FJ0Xf4XUL0D2VA4dZV532GHNB1JicxLko=",
      "url": "_framework/System.m0fu6d0eya.wasm"
    },
    {
      "hash": "sha256-Rte+Cvgj5a4Ixr4QxNe8TZefJSv0a6cUo1Oy+I4p7+M=",
      "url": "_framework/UnizaScheduleApi.6omehzh9o1.wasm"
    },
    {
      "hash": "sha256-BlatNL4XG/8r9j7xf/fKPSxanQKTcUugC+TL+exgVxo=",
      "url": "_framework/UnizaScheduleTable.ue7ayod6ui.wasm"
    },
    {
      "hash": "sha256-A8T3JtwONxD2x2gn3zA/kLMbPYZk/2RcLPT310zpa1w=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-gD2XMSIt+vtDFirTg+LVASuuDVoOW3S7fY2a27Ou3Vs=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-83CQmKheo75TsLhj/dTkeof2GIpmr6Kb8z9ty206FYc=",
      "url": "_framework/dotnet.native.nfwfnqgsnj.js"
    },
    {
      "hash": "sha256-CZnM7L28jVYl4qOE3Dkydd0bPpVyvYRiWGIoyjJmQMo=",
      "url": "_framework/dotnet.native.p0ny869ek9.wasm"
    },
    {
      "hash": "sha256-oBRKHAqZUsvCRnCzkQfB7zc45cpKLNq2NKyrG10IKx8=",
      "url": "_framework/dotnet.runtime.st3wwc8rqy.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-18utkeLhXxDQK8ecOL47ee317R3GjiUTS6dgA+E1Qgc=",
      "url": "_framework/netstandard.d37l9h98iz.wasm"
    },
    {
      "hash": "sha256-yis2dNdJ6e9R472mcuwUOsxBPCQX3snSMmHAL3zu2D8=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-z8OR40MowJ8GgK6P89Y+hiJK5+cclzFHzLhFQLL92bg=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-kC4Jby8uF35HlkTslhz2EJgOqeb90TPaxvYKL6lNlaU=",
      "url": "index.html"
    },
    {
      "hash": "sha256-DYKnOC5Czz0kD35D1nPhOlmGjZk3OBcOo3+Mfb6BmAU=",
      "url": "manifest.webmanifest"
    }
  ]
};
