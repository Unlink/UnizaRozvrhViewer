self.assetsManifest = {
  "version": "077aK1Cq",
  "assets": [
    {
      "hash": "sha256-yHHBqpG7L1p3ADuhoK3EBMCBjkh7+L7mFKOUed6mibw=",
      "url": "RozvrhUniza.styles.css"
    },
    {
      "hash": "sha256-Jga3CUuNfwvpwnsHZxpWURvivrlrEqnUo9XR5EOLYGc=",
      "url": "_framework/ClosedXML.6d8ybop3kc.wasm"
    },
    {
      "hash": "sha256-bN619zkNwVyqGT2tFn5NMXPDIo3OUVaRYMG/tXRtn+A=",
      "url": "_framework/ClosedXML.Parser.kcd8ka7nog.wasm"
    },
    {
      "hash": "sha256-xKqeqIQ1TDUTD1VdIoWdiNLEIGuxWKmTQB3d0S7bLF8=",
      "url": "_framework/DocumentFormat.OpenXml.Framework.w9qjrpieot.wasm"
    },
    {
      "hash": "sha256-CsWxN9Ml/p0K+b8ZdZtDc1MeTw3kcXnta5uvcgYEwFQ=",
      "url": "_framework/DocumentFormat.OpenXml.ym52o96kep.wasm"
    },
    {
      "hash": "sha256-DWrWJf+NGbjj12iqpO+Ufl4YS0bkW1yz6JwjocU15wY=",
      "url": "_framework/ExcelNumberFormat.zkc9yronjy.wasm"
    },
    {
      "hash": "sha256-Ni25oSB++69DYSmCmWs5Spnbu8YO2FpjBj34kKE+uLI=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.yphmymrgtg.wasm"
    },
    {
      "hash": "sha256-1bZXAq7xg/K+UZT3zZxmJHp4UKNJQBP+2ny+/lGkyHo=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.rwpg67y8a3.wasm"
    },
    {
      "hash": "sha256-Zv8J3ZDa8ogIlekjOFPtzXp5zU0bzwu5wwUPZMZL7SM=",
      "url": "_framework/Microsoft.AspNetCore.Components.ui4mfwpnd6.wasm"
    },
    {
      "hash": "sha256-zaHCBrRXAFuOMETGRVpV0g2MyMtc7qajuH+pMRNR2D8=",
      "url": "_framework/Microsoft.Bcl.HashCode.fhc460s73x.wasm"
    },
    {
      "hash": "sha256-3ADlF4CLU1Q+dQbj0MnPVnEJPiA4q4Jv5xxmiGEvBks=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.85u9862gz3.wasm"
    },
    {
      "hash": "sha256-kKMubKJ3c2lATxpoAuoDqMjzQ+a0M6Ym35pK74cMK2o=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.0cm6d8ej68.wasm"
    },
    {
      "hash": "sha256-fN4AyqImDQ+h3H7tFeF4ZSkjIHJ7qWgbKL217x6P53s=",
      "url": "_framework/Microsoft.Extensions.Configuration.cyz6aj3end.wasm"
    },
    {
      "hash": "sha256-vOEd7hoFklcaq4sqkEeKpoKcuXLNFPQPVoT1tDkiV8E=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.4q1w9mpnm0.wasm"
    },
    {
      "hash": "sha256-Sgs1bgmGaF2mv6rWcaihc+x48ZQQAidfzYwZvYX5WJk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.uum8fsrbn4.wasm"
    },
    {
      "hash": "sha256-popOehVNGTqgvhfA2lSicGjVt9GIh0S5UGL16TYC140=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.qcx6vuhv5d.wasm"
    },
    {
      "hash": "sha256-I/euMiwOKn2U2Y1vqcUjYWEG/7zWmvDiTlHAoPLRHQ0=",
      "url": "_framework/Microsoft.Extensions.Logging.p9svcbtg1a.wasm"
    },
    {
      "hash": "sha256-zb8jFz8oWzH9QDCIv6znwkEZEqBZjRrXTb7biON1h4o=",
      "url": "_framework/Microsoft.Extensions.Options.z0tlm9uxjf.wasm"
    },
    {
      "hash": "sha256-WXYpl64HUqc9+prJOz6dOEVvB8PFJhTdfqUMB3ZGRGA=",
      "url": "_framework/Microsoft.Extensions.Primitives.5pxr7nzxwe.wasm"
    },
    {
      "hash": "sha256-ubnFa4Rtxgu4gPe/SRKYk17LxS0CtEOnEoPvT6ITOTo=",
      "url": "_framework/Microsoft.JSInterop.7kva84rxiz.wasm"
    },
    {
      "hash": "sha256-mpyjzA6YBuV9Qx5BUC8YbXP9YjZlM+k7YTVawzXJFgk=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.imfqvv3x5h.wasm"
    },
    {
      "hash": "sha256-cHsLmPL/ZYfNtaqW793aQui9cR4N7JXjHm+xggcoz7w=",
      "url": "_framework/RBush.048ali807d.wasm"
    },
    {
      "hash": "sha256-DpRlCKFomDwgUDnzbbxas7L+0hbmTvYISQyGJYJ7KRY=",
      "url": "_framework/RozvrhUniza.6isf2phksp.wasm"
    },
    {
      "hash": "sha256-TYAwAMga8iYHgcD5+CMUwDAmCjtNUbzJJP6/e+Xtl5w=",
      "url": "_framework/SixLabors.Fonts.1ntl3xbxha.wasm"
    },
    {
      "hash": "sha256-xMF0eauQ5DkSzUozHLFFMQnL6DSJO09nJLtgag+Dzbw=",
      "url": "_framework/System.8rv0tdtrxz.wasm"
    },
    {
      "hash": "sha256-C+/fQ/aua0gCDbhZ7/2gXnBRdt20DYYGXdCsodHff40=",
      "url": "_framework/System.Buffers.vvxqd1zn23.wasm"
    },
    {
      "hash": "sha256-Oex7kxaTwDBMgX+w2BaJN/4fgmVbgWT3ExBCFnBXAvQ=",
      "url": "_framework/System.Collections.12ninwzy9g.wasm"
    },
    {
      "hash": "sha256-Yn6F62wt/Yee820weOYNaQDbRaKLdbfTcxv8vO/ic3Y=",
      "url": "_framework/System.Collections.Concurrent.66swrkipj1.wasm"
    },
    {
      "hash": "sha256-8uSwNa16gW2P2nCg0CDKYSFxxE6vbOYtGSQdnH/GcmM=",
      "url": "_framework/System.Collections.Immutable.ugj2wz4i0u.wasm"
    },
    {
      "hash": "sha256-S8eHCdKVJu79k/SNCDD6ucZxV/8WhU+/dDr6MJEumqY=",
      "url": "_framework/System.Collections.NonGeneric.l8kdpead9k.wasm"
    },
    {
      "hash": "sha256-OdAuGIh7lQRFl44DSel0yIT0uMl3xVMUMvkoHj0pHK4=",
      "url": "_framework/System.Collections.Specialized.ldl4vj6qa8.wasm"
    },
    {
      "hash": "sha256-Izui+Uc/SfLd/ZVL/zIwFoTUVNYIc6szZFW8QwBKgsw=",
      "url": "_framework/System.ComponentModel.Primitives.t0ckf3fs2j.wasm"
    },
    {
      "hash": "sha256-Gd872eGJlirZOK9DDLvXGU/ztX1JRQDH4CY3FFFmiiA=",
      "url": "_framework/System.ComponentModel.TypeConverter.n0hjgdu8ku.wasm"
    },
    {
      "hash": "sha256-pYLaBeWMzy5oE2tWeKNL/PMnam15+r4QjbORp+HRYME=",
      "url": "_framework/System.ComponentModel.ty8x74ifk3.wasm"
    },
    {
      "hash": "sha256-impSSXOvVI1OlM3VB67h2UWC8s89uwvX6Hgpj61TXr4=",
      "url": "_framework/System.Console.2u9f7xoyjt.wasm"
    },
    {
      "hash": "sha256-mFgVWZTFbPmGB/53berSXKrNGyYRCwPLqlkyJEx/nt0=",
      "url": "_framework/System.Data.Common.0ymlg0jwjq.wasm"
    },
    {
      "hash": "sha256-j6z9Ids2xyzU0sJ4rfgNIH20mUxKdgfc+M/NktQhwkM=",
      "url": "_framework/System.Diagnostics.Debug.ddxqkx78sm.wasm"
    },
    {
      "hash": "sha256-wFAsrNvmX0wIovecw3INJkK/SmkXtqL/WM06Ce+wjHg=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.0ouyxo2hmc.wasm"
    },
    {
      "hash": "sha256-g3haiw19wvwcCMWMdMT7PPmTWZqgTbckwMBfMwGaNt8=",
      "url": "_framework/System.Diagnostics.Tools.f1tqnbqptf.wasm"
    },
    {
      "hash": "sha256-mWbEDlfwGfGbx5ACO4/5zEnXOkbCtS0e4ki9SViT7j0=",
      "url": "_framework/System.Drawing.Primitives.rv7emdt6ll.wasm"
    },
    {
      "hash": "sha256-wL9hReRO6JYKohMUiK0ts3ylL9+ypSji+KSFfJSuofA=",
      "url": "_framework/System.Drawing.wgem9d1jb2.wasm"
    },
    {
      "hash": "sha256-/6tMpBeZnppNKK157LQdlbr1MmbzUxC80e6E5t9qlbY=",
      "url": "_framework/System.IO.Compression.7qdyqeu8zb.wasm"
    },
    {
      "hash": "sha256-6K4qhWlDltYpwoWad6el+T0hjEyXLEL2dKLM2scBcJQ=",
      "url": "_framework/System.IO.Compression.Brotli.0ubwjmmpb6.wasm"
    },
    {
      "hash": "sha256-gyID4635rF9Gb08BtJE03ciuf6RGnWe1Bq+0ChcgRYo=",
      "url": "_framework/System.IO.FileSystem.nbq5uk2pnw.wasm"
    },
    {
      "hash": "sha256-nNiDUQb9iJcI9YDq62Ayt1s34f5dxQBjzsMjAVUSBqI=",
      "url": "_framework/System.IO.Packaging.sctom6k9ln.wasm"
    },
    {
      "hash": "sha256-FBW6K4TORa24v2L639DPjf309NTGkrj0iIqiJaPqcYA=",
      "url": "_framework/System.IO.Pipelines.wn1erg3up3.wasm"
    },
    {
      "hash": "sha256-liDPY7egl129E9QKhYfGf+0jbLrt8PSN+wsT5IWVtGc=",
      "url": "_framework/System.Linq.Expressions.uz2d3biufj.wasm"
    },
    {
      "hash": "sha256-gOCqhnNHnQrJmf2PxjjaUAw4D39v7hcqCUopgttJmJ0=",
      "url": "_framework/System.Linq.Parallel.oiecfzbbl8.wasm"
    },
    {
      "hash": "sha256-9zpgONE5c8E3RBZ3l/KWIpsbkDav30GBBLyJihlovJs=",
      "url": "_framework/System.Linq.f2612x8ay1.wasm"
    },
    {
      "hash": "sha256-z6CWkVNcmLOMnu3DmjaVlkY9SAWArLTqMxtd2kk7aJo=",
      "url": "_framework/System.Memory.d9irezxm4n.wasm"
    },
    {
      "hash": "sha256-FUbX693WCNXmQF7FQWymTQD2Qq0c5ppKiI8RQY4y4M4=",
      "url": "_framework/System.Net.Http.bsnei6a22j.wasm"
    },
    {
      "hash": "sha256-VsWTEOyEbltVNWebWtzswCEfVLEN7seHoNS6agRLaJw=",
      "url": "_framework/System.Net.Primitives.e24bsgwgy3.wasm"
    },
    {
      "hash": "sha256-CDv9/gyRnLJbqlh/asNUBvT/TDmwwJi1P3Mj7ghkph4=",
      "url": "_framework/System.Numerics.Vectors.4poczcktxm.wasm"
    },
    {
      "hash": "sha256-+xoHHHvJRg5NhNnkGByIMOtV6Ng9ixhhRgu4cnV3Jvw=",
      "url": "_framework/System.ObjectModel.zq3c5680id.wasm"
    },
    {
      "hash": "sha256-r+s37sX59YhzNKioKpCh7sKLn5q0DdIOevUI0iK+F5s=",
      "url": "_framework/System.Private.CoreLib.v0tntnoa34.wasm"
    },
    {
      "hash": "sha256-9fXXx1lVI3uC/lgeR0X9HPW9LmaJOhVLYs01Os1Mez0=",
      "url": "_framework/System.Private.Uri.3mzzvvx878.wasm"
    },
    {
      "hash": "sha256-SIxecV0+7VDS7lmqkbeYNmUkCHnOnjh7tLexgufbQQo=",
      "url": "_framework/System.Private.Xml.Linq.4xx4jnon5z.wasm"
    },
    {
      "hash": "sha256-bCxHlbjJz8FPzlTt++YIpHZr/dJi+mbx5rgTaOoSCB8=",
      "url": "_framework/System.Private.Xml.o17jqe3c6j.wasm"
    },
    {
      "hash": "sha256-A9wNq0nDXvUnnDswgMqHD1Bz9L5ezaMlz7ewIdx4Fv8=",
      "url": "_framework/System.Resources.ResourceManager.ry248jky63.wasm"
    },
    {
      "hash": "sha256-TYuHQrGsE3QDUVu0IJtLF0sAWOLTc8YyUALrhlUM3Ho=",
      "url": "_framework/System.Runtime.1b8l62a7jv.wasm"
    },
    {
      "hash": "sha256-vhkClYxqkrF/GTeHJJ7a1UjuiKLKkine4vlf9nKV2Xw=",
      "url": "_framework/System.Runtime.CompilerServices.Unsafe.66m683fub6.wasm"
    },
    {
      "hash": "sha256-kQ4Vtj2ZL8cdzWyb0Vb/ByNsurUdP7TEKcbjjEHACT0=",
      "url": "_framework/System.Runtime.Extensions.th1ssf2rty.wasm"
    },
    {
      "hash": "sha256-dr2zPg+11BQOd27TZPxcs18PqUREGUfAtTD9nRdz7sw=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.it9v611w20.wasm"
    },
    {
      "hash": "sha256-+KCilYmENtuExI/5VTI0nTA0EOOcfImzEICjWXwlC8U=",
      "url": "_framework/System.Runtime.InteropServices.RuntimeInformation.cbbvk82p7y.wasm"
    },
    {
      "hash": "sha256-jl33iThcWZpJw2vPI2sybRWXmyvI8AO3e/xSZni/Oa0=",
      "url": "_framework/System.Runtime.InteropServices.ijdofhjyyf.wasm"
    },
    {
      "hash": "sha256-DNEc8UXfG1KPtjI0H5gT9PQLK4Ym2ORCDLBLvKMTdEw=",
      "url": "_framework/System.Runtime.Numerics.w1jmpj40cs.wasm"
    },
    {
      "hash": "sha256-u3p9IsYbyMy6KBUltXD7jDPPu3tN9y2K9F484BN1KPQ=",
      "url": "_framework/System.Security.Cryptography.5k7ku1q4sb.wasm"
    },
    {
      "hash": "sha256-SQ1+aS+lCxp43qhvbxWS01rhQfbvNeDSN0xyk2P9/Hc=",
      "url": "_framework/System.Text.Encodings.Web.hq94nfnuw2.wasm"
    },
    {
      "hash": "sha256-+ycKfkWOtagQxO/T0VrRhAg5pGXWiz3qM7Pjpfb4fKM=",
      "url": "_framework/System.Text.Json.3e86c3g1z8.wasm"
    },
    {
      "hash": "sha256-ID2Bg314Z4JLPgrq8Bs1XoehfIOd95++RKmHuM9V9ng=",
      "url": "_framework/System.Text.RegularExpressions.08wgmc71ya.wasm"
    },
    {
      "hash": "sha256-0yRaUKzcVwCbOwEdDLPbOpBaMR002LEl6kVncyVjd9A=",
      "url": "_framework/System.Threading.9pieh1zkdl.wasm"
    },
    {
      "hash": "sha256-cgRW9EBYuQ0gKwQbqB5lB1ITJSW8xSvfST4Z3my6W3s=",
      "url": "_framework/System.Web.HttpUtility.ed9o3z7c7y.wasm"
    },
    {
      "hash": "sha256-5claBNmyy8L12DFLS17Fh4SBiTjwhYts3ds7g8dX8Gc=",
      "url": "_framework/System.Xml.Linq.fnt4rzi185.wasm"
    },
    {
      "hash": "sha256-viH0Nr/SSUCuWnGb8jovNUQ0Ni6LaU4kOuIfOi+Xj2k=",
      "url": "_framework/UnizaScheduleApi.mf9evi7h8x.wasm"
    },
    {
      "hash": "sha256-OxoHW/9zUzKQS/Kycr7bolRhOVowsLiBa+aTqFf4/WE=",
      "url": "_framework/UnizaScheduleTable.tefj96djis.wasm"
    },
    {
      "hash": "sha256-CjAVUSXRltV7xId02K0X01eiOKJd/RHy1JSn5jlzLwk=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-N+/jRbIsqVbSKyrJpXTfko/MbGFn4mYhGgK+pW+zQ7o=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-/tR6fC/vFOKBJCQkoU7rjhL7aPe5g725jTStfrFnVxA=",
      "url": "_framework/dotnet.native.2oiair1ktq.wasm"
    },
    {
      "hash": "sha256-wm/t8nYa3LjQbMnZ61ZsIzDMXqZfOVA2GdBkTmFEibg=",
      "url": "_framework/dotnet.native.ucrf0ih7wd.js"
    },
    {
      "hash": "sha256-yfXUv1l/B489E8p12JxUvxly0JvHL9CCsoZUDlfGH9c=",
      "url": "_framework/dotnet.runtime.drv0pr9n5o.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-MKUSNuhon9vW6r1r15fh5AxIfoqizGzlBJ9nlcBHp9k=",
      "url": "_framework/netstandard.0c6f9lzp5x.wasm"
    },
    {
      "hash": "sha256-2RmJypat+qfxwZjruog7wgE6zxq7G79s0lk7r/HMtAQ=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-z8OR40MowJ8GgK6P89Y+hiJK5+cclzFHzLhFQLL92bg=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-YKx11+ph15XXrwvHZOQcUKFZpej4gWQQLRTixCTczcE=",
      "url": "index.html"
    },
    {
      "hash": "sha256-DYKnOC5Czz0kD35D1nPhOlmGjZk3OBcOo3+Mfb6BmAU=",
      "url": "manifest.webmanifest"
    }
  ]
};
