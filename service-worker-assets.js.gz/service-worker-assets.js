self.assetsManifest = {
  "version": "JXQCxj+Q",
  "assets": [
    {
      "hash": "sha256-yHHBqpG7L1p3ADuhoK3EBMCBjkh7+L7mFKOUed6mibw=",
      "url": "RozvrhUniza.styles.css"
    },
    {
      "hash": "sha256-Jga3CUuNfwvpwnsHZxpWURvivrlrEqnUo9XR5EOLYGc=",
      "url": "_framework/ClosedXML.6d8ybop3kc.wasm"
    },
    {
      "hash": "sha256-bN619zkNwVyqGT2tFn5NMXPDIo3OUVaRYMG/tXRtn+A=",
      "url": "_framework/ClosedXML.Parser.kcd8ka7nog.wasm"
    },
    {
      "hash": "sha256-P007bsef/CgRF9FEXHHPHbBnWpJyZrQ1FyCDtDaln8I=",
      "url": "_framework/DocumentFormat.OpenXml.Framework.vwmpdkddye.wasm"
    },
    {
      "hash": "sha256-ASP08XlPYziectPKspn6Qi+ESw5HTpDcVRLa64ukczI=",
      "url": "_framework/DocumentFormat.OpenXml.zzjzxj694v.wasm"
    },
    {
      "hash": "sha256-DWrWJf+NGbjj12iqpO+Ufl4YS0bkW1yz6JwjocU15wY=",
      "url": "_framework/ExcelNumberFormat.zkc9yronjy.wasm"
    },
    {
      "hash": "sha256-xt6NFnODu/C8G3U4vapEmp1Yf693AZC7tATBJL1v9Ms=",
      "url": "_framework/Microsoft.AspNetCore.Components.6pjuqaqgc0.wasm"
    },
    {
      "hash": "sha256-iyg4ec9jHFKp4LUFbVUQHlk36Ii7anIpyd59uKq80mw=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.hljxueyk5m.wasm"
    },
    {
      "hash": "sha256-apjuKEZ9tbWf402SXmIYK03VNjycswAa6vH8zJbBmDw=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.6w9arfc7uk.wasm"
    },
    {
      "hash": "sha256-zaHCBrRXAFuOMETGRVpV0g2MyMtc7qajuH+pMRNR2D8=",
      "url": "_framework/Microsoft.Bcl.HashCode.fhc460s73x.wasm"
    },
    {
      "hash": "sha256-I1V6RT2jU36RMO/udOCdtpwqRuricdlZ0IRsQvGrIKQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.9hvqdnyedj.wasm"
    },
    {
      "hash": "sha256-R8Rvf+ufvlMX05PSWGUXwGm3hty6uCI9EtqBH2FpDIQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.vejc7kiu4g.wasm"
    },
    {
      "hash": "sha256-UUwnFUGVKcfnwTDp5d2PPIYvZb3p3cZn9VEABGLlYu8=",
      "url": "_framework/Microsoft.Extensions.Configuration.b5r9igf1ej.wasm"
    },
    {
      "hash": "sha256-m9k4pt1S3OsB7nhPn3Spu1JjG5ixGwaWDws5UBzaZjs=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.3ajkzukr0v.wasm"
    },
    {
      "hash": "sha256-ExwDQeh4MflT5wdsZhstcI97V7nnmc41HC+7m/ePSg0=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.bio0krwjyk.wasm"
    },
    {
      "hash": "sha256-LzcTWyQxq144l85OIoqNEZ9baKA3Dp8K0zXOpMUA/RE=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.rdozhkd2tl.wasm"
    },
    {
      "hash": "sha256-Nw6fMz9mMm8SS3pPrUsobEC9zzLKC6AKDJhHRldk9VA=",
      "url": "_framework/Microsoft.Extensions.Logging.zh7psstrkj.wasm"
    },
    {
      "hash": "sha256-WsA7Qa5Zv/QmtZqrIEQLYVSPd55Hdc1S+2J7y4JQBJ8=",
      "url": "_framework/Microsoft.Extensions.Options.2abh528mcf.wasm"
    },
    {
      "hash": "sha256-QeF3pj2LH3LcaB6cg9nSyYQ6/Pf6RbTkLakVnAwVPXo=",
      "url": "_framework/Microsoft.Extensions.Primitives.vga3bvc9pt.wasm"
    },
    {
      "hash": "sha256-N8RKL2Eil4ZFxIkWa6Uig12+nRHOstda562q7GCs9fE=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.nsfh695mwg.wasm"
    },
    {
      "hash": "sha256-jMQY/dvs5uRhemYHS9FJ2U/551fHVVFNfoiVX8bIXQQ=",
      "url": "_framework/Microsoft.JSInterop.opjjuvycl4.wasm"
    },
    {
      "hash": "sha256-cHsLmPL/ZYfNtaqW793aQui9cR4N7JXjHm+xggcoz7w=",
      "url": "_framework/RBush.048ali807d.wasm"
    },
    {
      "hash": "sha256-oyDhOVFE1/C4bcDIXJGqsNeaidL74UItfiOZhjO6ub4=",
      "url": "_framework/RozvrhUniza.h36y8p0ijf.wasm"
    },
    {
      "hash": "sha256-TYAwAMga8iYHgcD5+CMUwDAmCjtNUbzJJP6/e+Xtl5w=",
      "url": "_framework/SixLabors.Fonts.1ntl3xbxha.wasm"
    },
    {
      "hash": "sha256-vPEm2KqgXqruGwnz718iSgmDoB8Img7iH3FzO57b0Rg=",
      "url": "_framework/System.400l3mulw9.wasm"
    },
    {
      "hash": "sha256-Jf27kWlVTv9oLvx0KOyDGlFRl/JwlMC4wCWiFigSsWs=",
      "url": "_framework/System.Buffers.pjm4uleil8.wasm"
    },
    {
      "hash": "sha256-ZXAjJs3Lhq8b4la/AF4aHZjPUi9PoD6UPY/z5EdZ3hA=",
      "url": "_framework/System.Collections.1dlhiqrx8w.wasm"
    },
    {
      "hash": "sha256-3cOmet0H5+3/5ypfWXDIJdnT11A0+3XB6sz53Grz9Wc=",
      "url": "_framework/System.Collections.Concurrent.ba715jlfco.wasm"
    },
    {
      "hash": "sha256-Cps0uPVfvYJRWtAS5c97AEekJBgnl1rSwsoL4paheaI=",
      "url": "_framework/System.Collections.Immutable.m9rg5ae979.wasm"
    },
    {
      "hash": "sha256-10O2TwtJMEy//ytf2caKsJzIR+JOq2Kv/B0C/zWbeEE=",
      "url": "_framework/System.Collections.NonGeneric.p4k14f4lfr.wasm"
    },
    {
      "hash": "sha256-FyrHyad2qsbtENQtUmmQdS235LP444VdmEiTycINCRo=",
      "url": "_framework/System.Collections.Specialized.51o517n5jz.wasm"
    },
    {
      "hash": "sha256-W0sqWnvZEhHlH8v4FYn/99AoG159GrkDddSvrVk/Dkg=",
      "url": "_framework/System.ComponentModel.Primitives.h5mqiso8w0.wasm"
    },
    {
      "hash": "sha256-ek4m7fTDznSiJqmKqIExI7PT0yBuoqujmiKn34guYt4=",
      "url": "_framework/System.ComponentModel.TypeConverter.mckqk9vqpi.wasm"
    },
    {
      "hash": "sha256-eIa8P9d6+k7PI95giXJV/uZ+Q/Kg4vxkRI2Z0S+DWL0=",
      "url": "_framework/System.ComponentModel.s7fa23eokj.wasm"
    },
    {
      "hash": "sha256-isiEadRd36HqLsLMxWICtezlNe/W4f8/AsX8RXGN+pw=",
      "url": "_framework/System.Console.60jdeaafsa.wasm"
    },
    {
      "hash": "sha256-wLrIQfahhKjCpuCb4eUG6oIw6wvnc+Zr1xGUbOLjjaE=",
      "url": "_framework/System.Data.Common.wo460iajuw.wasm"
    },
    {
      "hash": "sha256-wPPbAyJ/n7gF/K2SWe5W5yOfKq0N/xUYqroLwqglbXk=",
      "url": "_framework/System.Diagnostics.Debug.k38ray8cnl.wasm"
    },
    {
      "hash": "sha256-jrk3K9uH4tmkPet/mjXaUiy07XQNRdrIaVHbz1joRmY=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.aqcwe03tkn.wasm"
    },
    {
      "hash": "sha256-lkF1ZwihBRkDPCHg9Ml9BotAHITUUV1jKioPsKtf2K4=",
      "url": "_framework/System.Diagnostics.Tools.y9nb3hrudb.wasm"
    },
    {
      "hash": "sha256-WTUEUv2HGG9GRCsx+hzQ8IHH4ivJsXxV4dfoIxg+2Kw=",
      "url": "_framework/System.Drawing.Primitives.5dw2d2fbdt.wasm"
    },
    {
      "hash": "sha256-NFpXLgCTsyBU+AK+27QTsQQxyAoaLo/HDVh9RRvDIL4=",
      "url": "_framework/System.Drawing.c6tmp1gjc8.wasm"
    },
    {
      "hash": "sha256-jejlRDZa31AshoN7JnA80mISQ/l97TJtG6WbmzSE2v0=",
      "url": "_framework/System.IO.Compression.99ghky20x0.wasm"
    },
    {
      "hash": "sha256-Qkpvcpv1Go2d4Vwlu9WrUvUwoZqk+nV7rpAr8swrMsY=",
      "url": "_framework/System.IO.Compression.Brotli.yneibwvthl.wasm"
    },
    {
      "hash": "sha256-QN9dS2pNrgjtUxRL717Lmor+9zmBhxzHyzFWMhno3dk=",
      "url": "_framework/System.IO.FileSystem.0s5eswzbeb.wasm"
    },
    {
      "hash": "sha256-PkekakNgAoDlb0ZFZ4qfIeNujqVFRPry/O9Sqfp9jxc=",
      "url": "_framework/System.IO.Packaging.6zlqbfo76n.wasm"
    },
    {
      "hash": "sha256-fZpB2NFmoDJXAqnCYU4+XAKkZbE51ViM3KsQ+bxqVOo=",
      "url": "_framework/System.IO.Pipelines.px0vglstfo.wasm"
    },
    {
      "hash": "sha256-jhFHudGC5s8KEnhbBedc57gg3YDO3szw//dYUCzUUfQ=",
      "url": "_framework/System.Linq.Expressions.mqlqhc8hab.wasm"
    },
    {
      "hash": "sha256-iLQc0QFXbQWSnRyPgt1FY3nrJRmXi8mCRntxVxHuY9g=",
      "url": "_framework/System.Linq.Parallel.0ektnu5hkw.wasm"
    },
    {
      "hash": "sha256-9KQCG4nZVRfWZkvxriF1281IH1RCzU1L5jFcKMtJc9k=",
      "url": "_framework/System.Linq.gjpv0202lg.wasm"
    },
    {
      "hash": "sha256-8m2otWc+YNck3aCFb5zWRNrSkNjWIG5LLEHAg1yc85g=",
      "url": "_framework/System.Memory.upl8u4m2zr.wasm"
    },
    {
      "hash": "sha256-CjjU07YWj0D1SGfbs7RghgcNBkfIPtC2TAYgur7sMrY=",
      "url": "_framework/System.Net.Http.qj7na2bg8x.wasm"
    },
    {
      "hash": "sha256-eSkmLWnZ3RkSwQTH7dunFXMwU+BM4C35r9dvdzASvUk=",
      "url": "_framework/System.Net.Primitives.llz1zzlk2t.wasm"
    },
    {
      "hash": "sha256-79McEGIgNQ2rjc9UWp3vSmL/n3+lsMy4apD8D8OULLs=",
      "url": "_framework/System.Numerics.Vectors.1cu6lue4lt.wasm"
    },
    {
      "hash": "sha256-YSHeIqt2sIQbqmVI78evSi4fCYi79yE3v6+wy30kIQo=",
      "url": "_framework/System.ObjectModel.hwhr27t0wm.wasm"
    },
    {
      "hash": "sha256-d3FKuJDzkD1fSrVH1KyOv+1sQpXyyOUpxfolHc+yw/w=",
      "url": "_framework/System.Private.CoreLib.ve687ivnfe.wasm"
    },
    {
      "hash": "sha256-j+IgMAvscoUpRQbjm2Z/pDdmwENQLD7z5bbRIcD5h10=",
      "url": "_framework/System.Private.Uri.f4jrhqzf82.wasm"
    },
    {
      "hash": "sha256-tw5n8qH1ogAqMELc3Rq/5aBzVVJ3/xUa+4cEHtCKy6s=",
      "url": "_framework/System.Private.Xml.3lkur05guw.wasm"
    },
    {
      "hash": "sha256-xniBfueGnMtgfARv+GX5ESbC2k1Z2nXQOUHn8TyQn44=",
      "url": "_framework/System.Private.Xml.Linq.yddc6x85oa.wasm"
    },
    {
      "hash": "sha256-48WtQORRYle1yu7mKz0UK+B8bPrEFMKWdBSReowbgK0=",
      "url": "_framework/System.Resources.ResourceManager.9hr4affkg0.wasm"
    },
    {
      "hash": "sha256-4JjqZOhbK+h0/CIQTGVqHAWAjiTF/q0vHcj07po/Jhc=",
      "url": "_framework/System.Runtime.CompilerServices.Unsafe.wcpi0i4qbx.wasm"
    },
    {
      "hash": "sha256-LGSXhRDo+/sVzkiRyxtq6gMsIfEHM9JGLLIvlCCrsIk=",
      "url": "_framework/System.Runtime.Extensions.8tpy5mv29f.wasm"
    },
    {
      "hash": "sha256-subN4GeRX41RGMetqHoww+/Yr+o/uCpaS9oTrMeKJr0=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.ae3uao1vst.wasm"
    },
    {
      "hash": "sha256-3w2SYeMOGTH3LZJTu8pr0JD5A6K5H8Rv40A/qv+1pgw=",
      "url": "_framework/System.Runtime.InteropServices.RuntimeInformation.puxzs0c4xu.wasm"
    },
    {
      "hash": "sha256-3zzRuBKqoJtb0lgJoeRno6qZYxXi1JkLdtEbZIlS6Qw=",
      "url": "_framework/System.Runtime.InteropServices.j3y59az3mn.wasm"
    },
    {
      "hash": "sha256-aciaqfbFjxANrQsBCn4qV43S/AI6DyqAUBxlBvRQRtk=",
      "url": "_framework/System.Runtime.Numerics.p0pf4u2vyg.wasm"
    },
    {
      "hash": "sha256-PGsenc0U8tZcWpmrFOJ1fwSu69pCJmn1b+qHdb2F+JI=",
      "url": "_framework/System.Runtime.kuvoc22b94.wasm"
    },
    {
      "hash": "sha256-CGt8AvnS0ARiI+qEytVsFNYakzGIgZEZd9XHYVR9xLw=",
      "url": "_framework/System.Security.Cryptography.k9rwh2ycl3.wasm"
    },
    {
      "hash": "sha256-ZR1iHx10GyHDjW88DLb2dv0cLYu29h2RhNwFC/zJWiA=",
      "url": "_framework/System.Text.Encodings.Web.zmqv2qq7w9.wasm"
    },
    {
      "hash": "sha256-+TddoTCtuhjF1YBzO6ZC5YfYslHLVZGNSlAVy4XH+FQ=",
      "url": "_framework/System.Text.Json.3xanpuob4m.wasm"
    },
    {
      "hash": "sha256-Bmyqj+RCAPnUqu/Tmbvvef7+I3IZWQtY4tmSStWzHxg=",
      "url": "_framework/System.Text.RegularExpressions.agzux5x62p.wasm"
    },
    {
      "hash": "sha256-9X1vtwB68lfY51lKGj1518bWdCEtR0885I9QIUQQjDE=",
      "url": "_framework/System.Threading.b4jxnz8dx9.wasm"
    },
    {
      "hash": "sha256-Su9vKuJsmeFUc3TuVxHykaDF/3XkMEMgKDsQRDB+lQs=",
      "url": "_framework/System.Web.HttpUtility.2i03iqplwy.wasm"
    },
    {
      "hash": "sha256-e5txtle0V/jlZ+5laxHe+k2o2xewHh66AVpDrj8yXlc=",
      "url": "_framework/System.Xml.Linq.pzw688hdq1.wasm"
    },
    {
      "hash": "sha256-B5wkXA7cOSK7x87wMGg96piVmLtG/m15QZ4a8EPnmTM=",
      "url": "_framework/UnizaScheduleApi.59vzjm1fcc.wasm"
    },
    {
      "hash": "sha256-7vTpS7yRoJHh6KMKdvxsmUdgkwxmSbllwjfK0y2WVQU=",
      "url": "_framework/UnizaScheduleTable.aqa7xqjt7z.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-6CiE5D1/Mnp7Hw9nlqKDPrHPGw3q8sroU78h2iYXtX0=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-8E86eLcuNtjhqwycpBxmQiZSan5AQUgE+Io17VFaUsk=",
      "url": "_framework/dotnet.native.gstd8ce90v.js"
    },
    {
      "hash": "sha256-IoNQ4miki55RwDL+u0sc2wz+q8f7gJVhvOkD1jplTW0=",
      "url": "_framework/dotnet.native.ykr66v57l9.wasm"
    },
    {
      "hash": "sha256-QbnqrZGHtGq7wudS17/AYEPpH9JkphrsyVllD6JHmds=",
      "url": "_framework/dotnet.runtime.v06hirbjsv.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-vPmEmavtZZiV9Vvu5UfUF9BqXMVc6h9fmR429Ox5Klw=",
      "url": "_framework/netstandard.8zhtqzgxc5.wasm"
    },
    {
      "hash": "sha256-ncpoqcgh2d83pGh1b5/9ME4eNC9KaGasDjM+7zFDQs4=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-z8OR40MowJ8GgK6P89Y+hiJK5+cclzFHzLhFQLL92bg=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-rT4FH5+oxTvFqLsgN7KD+p7hVdmuum5ntNwjbKuGwJg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-+KfKAgID604Cz48JSPVzAr/ALZIYAM6qYr0Txa6AUBs=",
      "url": "js/service-worker-interop.js"
    },
    {
      "hash": "sha256-DYKnOC5Czz0kD35D1nPhOlmGjZk3OBcOo3+Mfb6BmAU=",
      "url": "manifest.webmanifest"
    }
  ]
};
