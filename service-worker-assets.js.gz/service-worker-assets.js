self.assetsManifest = {
  "version": "me1y0prs",
  "assets": [
    {
      "hash": "sha256-yHHBqpG7L1p3ADuhoK3EBMCBjkh7+L7mFKOUed6mibw=",
      "url": "RozvrhUniza.styles.css"
    },
    {
      "hash": "sha256-Jga3CUuNfwvpwnsHZxpWURvivrlrEqnUo9XR5EOLYGc=",
      "url": "_framework/ClosedXML.6d8ybop3kc.wasm"
    },
    {
      "hash": "sha256-bN619zkNwVyqGT2tFn5NMXPDIo3OUVaRYMG/tXRtn+A=",
      "url": "_framework/ClosedXML.Parser.kcd8ka7nog.wasm"
    },
    {
      "hash": "sha256-P007bsef/CgRF9FEXHHPHbBnWpJyZrQ1FyCDtDaln8I=",
      "url": "_framework/DocumentFormat.OpenXml.Framework.vwmpdkddye.wasm"
    },
    {
      "hash": "sha256-ASP08XlPYziectPKspn6Qi+ESw5HTpDcVRLa64ukczI=",
      "url": "_framework/DocumentFormat.OpenXml.zzjzxj694v.wasm"
    },
    {
      "hash": "sha256-DWrWJf+NGbjj12iqpO+Ufl4YS0bkW1yz6JwjocU15wY=",
      "url": "_framework/ExcelNumberFormat.zkc9yronjy.wasm"
    },
    {
      "hash": "sha256-xt6NFnODu/C8G3U4vapEmp1Yf693AZC7tATBJL1v9Ms=",
      "url": "_framework/Microsoft.AspNetCore.Components.6pjuqaqgc0.wasm"
    },
    {
      "hash": "sha256-iyg4ec9jHFKp4LUFbVUQHlk36Ii7anIpyd59uKq80mw=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.hljxueyk5m.wasm"
    },
    {
      "hash": "sha256-apjuKEZ9tbWf402SXmIYK03VNjycswAa6vH8zJbBmDw=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.6w9arfc7uk.wasm"
    },
    {
      "hash": "sha256-zaHCBrRXAFuOMETGRVpV0g2MyMtc7qajuH+pMRNR2D8=",
      "url": "_framework/Microsoft.Bcl.HashCode.fhc460s73x.wasm"
    },
    {
      "hash": "sha256-I1V6RT2jU36RMO/udOCdtpwqRuricdlZ0IRsQvGrIKQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.9hvqdnyedj.wasm"
    },
    {
      "hash": "sha256-R8Rvf+ufvlMX05PSWGUXwGm3hty6uCI9EtqBH2FpDIQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.vejc7kiu4g.wasm"
    },
    {
      "hash": "sha256-UUwnFUGVKcfnwTDp5d2PPIYvZb3p3cZn9VEABGLlYu8=",
      "url": "_framework/Microsoft.Extensions.Configuration.b5r9igf1ej.wasm"
    },
    {
      "hash": "sha256-m9k4pt1S3OsB7nhPn3Spu1JjG5ixGwaWDws5UBzaZjs=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.3ajkzukr0v.wasm"
    },
    {
      "hash": "sha256-ExwDQeh4MflT5wdsZhstcI97V7nnmc41HC+7m/ePSg0=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.bio0krwjyk.wasm"
    },
    {
      "hash": "sha256-LzcTWyQxq144l85OIoqNEZ9baKA3Dp8K0zXOpMUA/RE=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.rdozhkd2tl.wasm"
    },
    {
      "hash": "sha256-Nw6fMz9mMm8SS3pPrUsobEC9zzLKC6AKDJhHRldk9VA=",
      "url": "_framework/Microsoft.Extensions.Logging.zh7psstrkj.wasm"
    },
    {
      "hash": "sha256-WsA7Qa5Zv/QmtZqrIEQLYVSPd55Hdc1S+2J7y4JQBJ8=",
      "url": "_framework/Microsoft.Extensions.Options.2abh528mcf.wasm"
    },
    {
      "hash": "sha256-QeF3pj2LH3LcaB6cg9nSyYQ6/Pf6RbTkLakVnAwVPXo=",
      "url": "_framework/Microsoft.Extensions.Primitives.vga3bvc9pt.wasm"
    },
    {
      "hash": "sha256-N8RKL2Eil4ZFxIkWa6Uig12+nRHOstda562q7GCs9fE=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.nsfh695mwg.wasm"
    },
    {
      "hash": "sha256-jMQY/dvs5uRhemYHS9FJ2U/551fHVVFNfoiVX8bIXQQ=",
      "url": "_framework/Microsoft.JSInterop.opjjuvycl4.wasm"
    },
    {
      "hash": "sha256-cHsLmPL/ZYfNtaqW793aQui9cR4N7JXjHm+xggcoz7w=",
      "url": "_framework/RBush.048ali807d.wasm"
    },
    {
      "hash": "sha256-kv3v670VSXSnbBaPW1w3Gdttg1MqvXgqb4BeLHVEozM=",
      "url": "_framework/RozvrhUniza.e88rwshi2v.wasm"
    },
    {
      "hash": "sha256-TYAwAMga8iYHgcD5+CMUwDAmCjtNUbzJJP6/e+Xtl5w=",
      "url": "_framework/SixLabors.Fonts.1ntl3xbxha.wasm"
    },
    {
      "hash": "sha256-y7NnWh8z8gPuKAQI4hhBL69y2e7NlYbHZDvyDbFBTHI=",
      "url": "_framework/System.1h5i8a3bq8.wasm"
    },
    {
      "hash": "sha256-ga5ZjqahvbTg3fgvXaJf0niy9awi+WePtQm5p/VIRrY=",
      "url": "_framework/System.Buffers.btmwue87xb.wasm"
    },
    {
      "hash": "sha256-sagboLojC1ayuHCskZNUwX81DtAE4ddwJ5nzcAc28DM=",
      "url": "_framework/System.Collections.Concurrent.bp4ir1hbol.wasm"
    },
    {
      "hash": "sha256-/57PaC+jdoL1nvj3/rxzflJ52tmaqsSEHfypRetil0I=",
      "url": "_framework/System.Collections.Immutable.hwb32go8h1.wasm"
    },
    {
      "hash": "sha256-SY4uLuRv/1XTq9BrTR8ACEQH1hCClkI9wc/D4/JAIWQ=",
      "url": "_framework/System.Collections.NonGeneric.j1c790hy5n.wasm"
    },
    {
      "hash": "sha256-Xn6NQeNKTDiqKV3dITJoAwVnwwua/mWpGF9DeQJy8q8=",
      "url": "_framework/System.Collections.Specialized.ycp1v36iky.wasm"
    },
    {
      "hash": "sha256-lOnNFSMJ33qq7YPNCkwbEEigApVbiTNQ0DrJjz8cu+I=",
      "url": "_framework/System.Collections.wrkhbyyfcw.wasm"
    },
    {
      "hash": "sha256-10ighKW73nLTKNbBFCZua7YZYu7+ZYEF7khPdgYqGq0=",
      "url": "_framework/System.ComponentModel.Primitives.heig6swp2m.wasm"
    },
    {
      "hash": "sha256-a9as1PBxKPPH/JRfvDjS/YEsM2IjHxKNM/og+sxyaRg=",
      "url": "_framework/System.ComponentModel.TypeConverter.9zi2dkuy3x.wasm"
    },
    {
      "hash": "sha256-N70eQuRdkf3AV/T+pXBJ990jKiSqPS+E8yZ2iA4jFS0=",
      "url": "_framework/System.ComponentModel.pwjcvl2tfh.wasm"
    },
    {
      "hash": "sha256-FrK7uMbRbR592kbucDC1GqB+ZXKNUbBpJUKanje6eOI=",
      "url": "_framework/System.Console.6cqfnqaf6f.wasm"
    },
    {
      "hash": "sha256-BevFrenB3+AKNxOlP1p6vI7Vt/a3M3vQhB5rs8feecQ=",
      "url": "_framework/System.Data.Common.tunhktvh7u.wasm"
    },
    {
      "hash": "sha256-9cKRS/v3to4hsvqI+EBZITbdBI2H1w/DpO9C0q5DflM=",
      "url": "_framework/System.Diagnostics.Debug.tmw3ffj36k.wasm"
    },
    {
      "hash": "sha256-hGEG5z/RpOcjnpj2yyK/w8RL4tc1K/KFHa5iPKq+QBg=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.gpjrhhbi40.wasm"
    },
    {
      "hash": "sha256-AXiTqYOk8xNBKYsyP7JOUZL9/AmkeHys4lsImABRAFY=",
      "url": "_framework/System.Diagnostics.Tools.lnfza93orj.wasm"
    },
    {
      "hash": "sha256-/CpE0KHIip76lfCsQhRdoyYhXGcoFiwYy3pHtm1A3VE=",
      "url": "_framework/System.Drawing.Primitives.c2z2bjq0ap.wasm"
    },
    {
      "hash": "sha256-fuFG0ksileDCE3MOsGjhBLpUBviTr3dDPuDfsktoW5c=",
      "url": "_framework/System.Drawing.e50j3te5oy.wasm"
    },
    {
      "hash": "sha256-ObOMTWNOvdabWRUX/TJpX4osecsUumXzclSLtIItiJ8=",
      "url": "_framework/System.IO.Compression.Brotli.venhsogzi5.wasm"
    },
    {
      "hash": "sha256-T90B8rv7rEMP/oZQkIPMDcc8GnutCx/gZpohZs33Hqw=",
      "url": "_framework/System.IO.Compression.nap1n81wvm.wasm"
    },
    {
      "hash": "sha256-SMkFjnRnQTI7lVsmtYI/mG8sLuJkVON0mlySYdfPLYM=",
      "url": "_framework/System.IO.FileSystem.02oek12ocg.wasm"
    },
    {
      "hash": "sha256-PkekakNgAoDlb0ZFZ4qfIeNujqVFRPry/O9Sqfp9jxc=",
      "url": "_framework/System.IO.Packaging.6zlqbfo76n.wasm"
    },
    {
      "hash": "sha256-YUHUP3fb8mUiEFOdfQqM/stc3OxmfyDdEIl8P1n6F5o=",
      "url": "_framework/System.IO.Pipelines.9azjszgsci.wasm"
    },
    {
      "hash": "sha256-7U9vholjEMiZsjzsQJBFLezRMSLQruCV3yb+8wjZIK8=",
      "url": "_framework/System.Linq.Expressions.zk6fh0jsx5.wasm"
    },
    {
      "hash": "sha256-6jcprRpmdD9OjdQhXrXoqJmFoPcJea/45C0MvmMwJKw=",
      "url": "_framework/System.Linq.Parallel.i6sh3vtwtz.wasm"
    },
    {
      "hash": "sha256-XdK5uH8aTdyqu0WYQmEucp+b9sRFIOUk/W1Nae0x1Hg=",
      "url": "_framework/System.Linq.z0kdv6zs0p.wasm"
    },
    {
      "hash": "sha256-csJ//Z4Jf4QymvKdmpxoyp6hVgOT3nMRykTkrGVVN3s=",
      "url": "_framework/System.Memory.6jwrx5v8ks.wasm"
    },
    {
      "hash": "sha256-JjOs2sRtmViYdAPCGUa0RopvoXdjWR52M5FrzsFn0po=",
      "url": "_framework/System.Net.Http.iy8a9i5o1d.wasm"
    },
    {
      "hash": "sha256-JOrd7O2wESUYge/PRYjeu3ooB6yZ5l36eXhcHdPe6xs=",
      "url": "_framework/System.Net.Primitives.cmknywwdix.wasm"
    },
    {
      "hash": "sha256-LtwGQqdCrBq/Ihpf8YpW93FNSaX/CdQyHwvCymxJ55U=",
      "url": "_framework/System.Numerics.Vectors.mncfihoa8n.wasm"
    },
    {
      "hash": "sha256-wUZFCQ2tpo3+0fu8DXbzEyunbkJP3pcMvguY3SMoTsg=",
      "url": "_framework/System.ObjectModel.zb59yhbth1.wasm"
    },
    {
      "hash": "sha256-69JRGhcvi3+t0a1gicRIXoYo0gr3rQpCwEL3c5eoA68=",
      "url": "_framework/System.Private.CoreLib.50lbi7674n.wasm"
    },
    {
      "hash": "sha256-80a9OnTdu57iQ0oa2TpVPQObCrkR6lYg/L1Q2V1h7aM=",
      "url": "_framework/System.Private.Uri.lall65qnx9.wasm"
    },
    {
      "hash": "sha256-3ov8HEv+rk2Dr63E/5snCpCW8qVq0Xvtx9B1EH+yeGY=",
      "url": "_framework/System.Private.Xml.Linq.2s7vn51ugo.wasm"
    },
    {
      "hash": "sha256-nvBxiApBk/2TCcrZBSPd0fOsMPGk7mWA55slIyw89X0=",
      "url": "_framework/System.Private.Xml.ych2n9tthv.wasm"
    },
    {
      "hash": "sha256-fbMi0QtBLHM+nsyeUnxTZHyD5XzKmsNDCyBVjkxPGRs=",
      "url": "_framework/System.Resources.ResourceManager.plv2jta2u1.wasm"
    },
    {
      "hash": "sha256-mo2y/v+zey8ez/bm9LFCX3trJwiFNnnfzdR0LIXvhuw=",
      "url": "_framework/System.Runtime.CompilerServices.Unsafe.qcdw6vqpki.wasm"
    },
    {
      "hash": "sha256-jZIkaDRxdZl5Me2csYlwyoZz0xpE5B40Spf733I12yc=",
      "url": "_framework/System.Runtime.Extensions.t8l8l0cynl.wasm"
    },
    {
      "hash": "sha256-ZnCxDIgL2uAKZG8rd0AWCRWyiHX3t29AKcxXurx1TLQ=",
      "url": "_framework/System.Runtime.InteropServices.6crcfbijde.wasm"
    },
    {
      "hash": "sha256-lf8bNUBMbJYeAqYxKK6pKywcrKELO2tVs32xlLoJd/M=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.l4nao9l17b.wasm"
    },
    {
      "hash": "sha256-XzDLjWUWUcFLUT4VpOBHgVVvVnrC3Y25lv6IzSW9liQ=",
      "url": "_framework/System.Runtime.InteropServices.RuntimeInformation.nup2h8fqw7.wasm"
    },
    {
      "hash": "sha256-7werLYn2LOIHTaVi8/ZikTLFu/PMG59SwMbp8PXH5S4=",
      "url": "_framework/System.Runtime.Numerics.fokdegdulb.wasm"
    },
    {
      "hash": "sha256-GI94VQSospLdbAV2dSmZjHyHA+mvUUDDI45lIN87Wj0=",
      "url": "_framework/System.Runtime.sj282gz0pf.wasm"
    },
    {
      "hash": "sha256-LP5TxfNf6OwDfrvFcpdlaoDUlUttfgv0I9QwuiOo21M=",
      "url": "_framework/System.Security.Cryptography.s8nexs6iz9.wasm"
    },
    {
      "hash": "sha256-n6Fx/gDIIxu+xNYkF7EHepd28xRp7T5RHALzXdn82FU=",
      "url": "_framework/System.Text.Encodings.Web.5r90xnj60u.wasm"
    },
    {
      "hash": "sha256-C2TlubVJsRqyVhDoh7Gl+2ePmXp/gCyYBLFZcU6b7lc=",
      "url": "_framework/System.Text.Json.hxcmpa12ob.wasm"
    },
    {
      "hash": "sha256-9V6AWELO+6tI70mIVXPNiiy6oZM5nxqmt7KCQzHBu7s=",
      "url": "_framework/System.Text.RegularExpressions.pn2uuuapsl.wasm"
    },
    {
      "hash": "sha256-aRpYwk+e1fGjhpBc8riL9+2gnsd6PUDAHSgtr+cdpS0=",
      "url": "_framework/System.Threading.31bnib3b71.wasm"
    },
    {
      "hash": "sha256-2/9C15zGfk7IvoFz8VxFL8YIX6ZqatRWisWKFTXpWa0=",
      "url": "_framework/System.Web.HttpUtility.xdbyau9ems.wasm"
    },
    {
      "hash": "sha256-CtCEVMVCGg9HoHtIFvGwAiLGJrg+KgImS+oc8purBE8=",
      "url": "_framework/System.Xml.Linq.224i7l5jfb.wasm"
    },
    {
      "hash": "sha256-+I4nao7w0L1v8Xr/JOKEp2UY4weVSt24azmdf/blMkU=",
      "url": "_framework/UnizaScheduleApi.0ifmbvp199.wasm"
    },
    {
      "hash": "sha256-FBpBJBqBZcbRamCGWL0TvSVWww/h+pVa3J2Gzia7nR4=",
      "url": "_framework/UnizaScheduleTable.so39vrqcg7.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-XDy60yTi2CeavxsbvYaBhiPgJdRMyb2PLdNMAxaJjmM=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-6CmhGMeMGSZmUY3amCh8yOL2tAVWWLqNd5McslBBQ0s=",
      "url": "_framework/dotnet.native.kxzkzxp21n.wasm"
    },
    {
      "hash": "sha256-MfSpGIZ87biLGJAvDaXeCKJWDgZhwJGoH3pM0y4t8Q8=",
      "url": "_framework/dotnet.native.zjs9jsruox.js"
    },
    {
      "hash": "sha256-MZMguyke9CroSQl+L/SHIGFkPTD+LtYGXkXjAvwWx40=",
      "url": "_framework/dotnet.runtime.zbexyp8zrs.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-Bu7WRTJYo+7CxQ3FfoXCN5G6eygu4gFuMqut4T6asTw=",
      "url": "_framework/netstandard.agff2xza6y.wasm"
    },
    {
      "hash": "sha256-ncpoqcgh2d83pGh1b5/9ME4eNC9KaGasDjM+7zFDQs4=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-z8OR40MowJ8GgK6P89Y+hiJK5+cclzFHzLhFQLL92bg=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-rT4FH5+oxTvFqLsgN7KD+p7hVdmuum5ntNwjbKuGwJg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-+KfKAgID604Cz48JSPVzAr/ALZIYAM6qYr0Txa6AUBs=",
      "url": "js/service-worker-interop.js"
    },
    {
      "hash": "sha256-DYKnOC5Czz0kD35D1nPhOlmGjZk3OBcOo3+Mfb6BmAU=",
      "url": "manifest.webmanifest"
    }
  ]
};
