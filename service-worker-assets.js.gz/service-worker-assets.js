self.assetsManifest = {
  "version": "LP0o5NEY",
  "assets": [
    {
      "hash": "sha256-yHHBqpG7L1p3ADuhoK3EBMCBjkh7+L7mFKOUed6mibw=",
      "url": "RozvrhUniza.styles.css"
    },
    {
      "hash": "sha256-Jga3CUuNfwvpwnsHZxpWURvivrlrEqnUo9XR5EOLYGc=",
      "url": "_framework/ClosedXML.6d8ybop3kc.wasm"
    },
    {
      "hash": "sha256-bN619zkNwVyqGT2tFn5NMXPDIo3OUVaRYMG/tXRtn+A=",
      "url": "_framework/ClosedXML.Parser.kcd8ka7nog.wasm"
    },
    {
      "hash": "sha256-P007bsef/CgRF9FEXHHPHbBnWpJyZrQ1FyCDtDaln8I=",
      "url": "_framework/DocumentFormat.OpenXml.Framework.vwmpdkddye.wasm"
    },
    {
      "hash": "sha256-ASP08XlPYziectPKspn6Qi+ESw5HTpDcVRLa64ukczI=",
      "url": "_framework/DocumentFormat.OpenXml.zzjzxj694v.wasm"
    },
    {
      "hash": "sha256-DWrWJf+NGbjj12iqpO+Ufl4YS0bkW1yz6JwjocU15wY=",
      "url": "_framework/ExcelNumberFormat.zkc9yronjy.wasm"
    },
    {
      "hash": "sha256-xt6NFnODu/C8G3U4vapEmp1Yf693AZC7tATBJL1v9Ms=",
      "url": "_framework/Microsoft.AspNetCore.Components.6pjuqaqgc0.wasm"
    },
    {
      "hash": "sha256-iyg4ec9jHFKp4LUFbVUQHlk36Ii7anIpyd59uKq80mw=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.hljxueyk5m.wasm"
    },
    {
      "hash": "sha256-apjuKEZ9tbWf402SXmIYK03VNjycswAa6vH8zJbBmDw=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.6w9arfc7uk.wasm"
    },
    {
      "hash": "sha256-zaHCBrRXAFuOMETGRVpV0g2MyMtc7qajuH+pMRNR2D8=",
      "url": "_framework/Microsoft.Bcl.HashCode.fhc460s73x.wasm"
    },
    {
      "hash": "sha256-I1V6RT2jU36RMO/udOCdtpwqRuricdlZ0IRsQvGrIKQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.9hvqdnyedj.wasm"
    },
    {
      "hash": "sha256-R8Rvf+ufvlMX05PSWGUXwGm3hty6uCI9EtqBH2FpDIQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.vejc7kiu4g.wasm"
    },
    {
      "hash": "sha256-UUwnFUGVKcfnwTDp5d2PPIYvZb3p3cZn9VEABGLlYu8=",
      "url": "_framework/Microsoft.Extensions.Configuration.b5r9igf1ej.wasm"
    },
    {
      "hash": "sha256-m9k4pt1S3OsB7nhPn3Spu1JjG5ixGwaWDws5UBzaZjs=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.3ajkzukr0v.wasm"
    },
    {
      "hash": "sha256-ExwDQeh4MflT5wdsZhstcI97V7nnmc41HC+7m/ePSg0=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.bio0krwjyk.wasm"
    },
    {
      "hash": "sha256-LzcTWyQxq144l85OIoqNEZ9baKA3Dp8K0zXOpMUA/RE=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.rdozhkd2tl.wasm"
    },
    {
      "hash": "sha256-Nw6fMz9mMm8SS3pPrUsobEC9zzLKC6AKDJhHRldk9VA=",
      "url": "_framework/Microsoft.Extensions.Logging.zh7psstrkj.wasm"
    },
    {
      "hash": "sha256-WsA7Qa5Zv/QmtZqrIEQLYVSPd55Hdc1S+2J7y4JQBJ8=",
      "url": "_framework/Microsoft.Extensions.Options.2abh528mcf.wasm"
    },
    {
      "hash": "sha256-QeF3pj2LH3LcaB6cg9nSyYQ6/Pf6RbTkLakVnAwVPXo=",
      "url": "_framework/Microsoft.Extensions.Primitives.vga3bvc9pt.wasm"
    },
    {
      "hash": "sha256-N8RKL2Eil4ZFxIkWa6Uig12+nRHOstda562q7GCs9fE=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.nsfh695mwg.wasm"
    },
    {
      "hash": "sha256-jMQY/dvs5uRhemYHS9FJ2U/551fHVVFNfoiVX8bIXQQ=",
      "url": "_framework/Microsoft.JSInterop.opjjuvycl4.wasm"
    },
    {
      "hash": "sha256-cHsLmPL/ZYfNtaqW793aQui9cR4N7JXjHm+xggcoz7w=",
      "url": "_framework/RBush.048ali807d.wasm"
    },
    {
      "hash": "sha256-7ngUxZ0gYXnI8SChJm4AyI+qK9uN1JuUO002R6Oj0Lo=",
      "url": "_framework/RozvrhUniza.aep2e7dayl.wasm"
    },
    {
      "hash": "sha256-TYAwAMga8iYHgcD5+CMUwDAmCjtNUbzJJP6/e+Xtl5w=",
      "url": "_framework/SixLabors.Fonts.1ntl3xbxha.wasm"
    },
    {
      "hash": "sha256-DKAKG2SDtKWqrsszOa+bhpI0EW+eeA3fKhUlK2Uk1rg=",
      "url": "_framework/System.Buffers.0pve412ucp.wasm"
    },
    {
      "hash": "sha256-aCjrEUJfYClL0JyQL8JkfSzKEx3K9pFrrraNRGNYh9c=",
      "url": "_framework/System.Collections.Concurrent.4d5l2azd2p.wasm"
    },
    {
      "hash": "sha256-9dXknSW6oee7mt+igYmmmX186Hq6Jw74uWnrApfibKg=",
      "url": "_framework/System.Collections.Immutable.36r2w1rver.wasm"
    },
    {
      "hash": "sha256-7fzKkTAU7L8wmPlzSjnT5fRIOe5qDkkCUpJ+fxMvOXk=",
      "url": "_framework/System.Collections.NonGeneric.hjrmcfako7.wasm"
    },
    {
      "hash": "sha256-kanMyJn5pMxbgHf36WwjUJO2nIIE6i1scygwZU7hO58=",
      "url": "_framework/System.Collections.Specialized.ddr85ik6gp.wasm"
    },
    {
      "hash": "sha256-IdGxrT8x+OMilbY9y6isQFe6g+Vh0TBg6WuygwBjNfY=",
      "url": "_framework/System.Collections.dppo9gh157.wasm"
    },
    {
      "hash": "sha256-hD+E+PlhugfAQxapLnf50hopB9r0db37eB1K2jLyNYw=",
      "url": "_framework/System.ComponentModel.0bzvssvmpm.wasm"
    },
    {
      "hash": "sha256-8ujrEMrvcnhA5759yYaBc6HkrxlmEgxwWkptlT7sKfQ=",
      "url": "_framework/System.ComponentModel.Primitives.i4x5icfvbt.wasm"
    },
    {
      "hash": "sha256-x7yM6th4jHA2LoxNZb6Bbq/esoP/Xa0QlK26v8403Tk=",
      "url": "_framework/System.ComponentModel.TypeConverter.bbbq9ms2r7.wasm"
    },
    {
      "hash": "sha256-eJYtS2NUHwQ/5ZdxfInkURrob1zNRkvDqiUn03HRcpA=",
      "url": "_framework/System.Console.80nkl0bwns.wasm"
    },
    {
      "hash": "sha256-xSCYcFIrcz8+tSYnvgAxHIL1wzFPl7OAkTbuZYC2tC8=",
      "url": "_framework/System.Data.Common.xd99lx7ryn.wasm"
    },
    {
      "hash": "sha256-GthSykJlTWaqJKwPsvfawJW3DEUXvTr7JKJVvZC7tzo=",
      "url": "_framework/System.Diagnostics.Debug.ix3wc8ub5a.wasm"
    },
    {
      "hash": "sha256-TrsEpPyio4eRSE7Wb7CdsGyGh3jcWRwzDDkcEp42Lxc=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.ae3ec8dz20.wasm"
    },
    {
      "hash": "sha256-VYUf3/5G+fqEV/tqV600hbjJoFC0DFEtk2Rmqv9FTqQ=",
      "url": "_framework/System.Diagnostics.Tools.z6rcartsoz.wasm"
    },
    {
      "hash": "sha256-p2c1iacM5gRlSC8exYLxq+pQ6PvdpsnGxsgxZM4ZjIw=",
      "url": "_framework/System.Drawing.Primitives.b3j4yb07iw.wasm"
    },
    {
      "hash": "sha256-ExiEXldajSXRA8hlBB/dgLKQ8pUu3C1XHu9Fk/8tAWk=",
      "url": "_framework/System.Drawing.hzrl70oes7.wasm"
    },
    {
      "hash": "sha256-g3AnkEeyGyBBz+MkXH7bkx9izTAgHp4ZgYzZtiR+AYI=",
      "url": "_framework/System.IO.Compression.Brotli.vddf7itfv4.wasm"
    },
    {
      "hash": "sha256-I0NYZk6V7uh15Mn57A2sBHV0EjMf4J/swYMtUcWgt8g=",
      "url": "_framework/System.IO.Compression.njabdvv5fc.wasm"
    },
    {
      "hash": "sha256-q7D/xumy2/6ZxzP49qtoSFRePWuKrub4jzxuC0IL94E=",
      "url": "_framework/System.IO.FileSystem.lc1ykst719.wasm"
    },
    {
      "hash": "sha256-PkekakNgAoDlb0ZFZ4qfIeNujqVFRPry/O9Sqfp9jxc=",
      "url": "_framework/System.IO.Packaging.6zlqbfo76n.wasm"
    },
    {
      "hash": "sha256-vB/mHpU8YWqbonbePTX22jmIRwgl+Gn2euzReK4v7es=",
      "url": "_framework/System.IO.Pipelines.8brogkqzjr.wasm"
    },
    {
      "hash": "sha256-SCIfRbQ1RYV3PZHjOD3B/EjC9yuyeWtpaQswfPELS+A=",
      "url": "_framework/System.Linq.4ldixvjtrx.wasm"
    },
    {
      "hash": "sha256-avGP1p2Vugra62o7f2ML3YDI3z3Bkl4b/0FeVfhkTU4=",
      "url": "_framework/System.Linq.Expressions.qjlqbdyvvc.wasm"
    },
    {
      "hash": "sha256-zb3rK0e0EUPHlRLFv72vyeuVZPjAgsLtIVYIAbpugw0=",
      "url": "_framework/System.Linq.Parallel.7nvwa4w4jd.wasm"
    },
    {
      "hash": "sha256-FKlxzlXirQ6chtGh/HrbYEJZwLW+E43cOJ8cR0HLFNw=",
      "url": "_framework/System.Memory.ol6eqhoqtn.wasm"
    },
    {
      "hash": "sha256-ngduOgv2v2nxwri/GAbb9bq1vGFuHlWkJyM93xCtzVk=",
      "url": "_framework/System.Net.Http.qutphhkn2o.wasm"
    },
    {
      "hash": "sha256-2EJntxQ6NdnA6e9uwoUQh831TusLEoO3/FFD5pUufv4=",
      "url": "_framework/System.Net.Primitives.oof72wja33.wasm"
    },
    {
      "hash": "sha256-ytrXSFgW2ZgVG8Swu9IB4bqZ5piEFmuzdxlJ9Vb+xic=",
      "url": "_framework/System.Numerics.Vectors.y6xv53lrgl.wasm"
    },
    {
      "hash": "sha256-JKRorSVYN+mg+MAlAD0lmFOxPvvVxvBSUhQHl/ywg4M=",
      "url": "_framework/System.ObjectModel.scd9clje02.wasm"
    },
    {
      "hash": "sha256-1lvc/ynjmy6ejVCvKzsmEXdJ0HYOJI6ct94ZULUDQPE=",
      "url": "_framework/System.Private.CoreLib.aszo9g76el.wasm"
    },
    {
      "hash": "sha256-WjI2CZxgGRWb2/9ftGOPjglZxg2kubrpMKFtX9BdMvg=",
      "url": "_framework/System.Private.Uri.2xkj9htyvi.wasm"
    },
    {
      "hash": "sha256-jTdDEN+QBUu7yL39gX1O1FIJynBL+rshrOIwcCst77w=",
      "url": "_framework/System.Private.Xml.Linq.fhgoniuagb.wasm"
    },
    {
      "hash": "sha256-gce3kPuq74zxkWJluTMMIq0CwSUwEiilxbcU86KZ3ro=",
      "url": "_framework/System.Private.Xml.r18z9bvq27.wasm"
    },
    {
      "hash": "sha256-2siDX2R0hv0mjSyI6MopvJfE8OZQPmWnVOUCwe6zaAg=",
      "url": "_framework/System.Resources.ResourceManager.a4wdhx1g8f.wasm"
    },
    {
      "hash": "sha256-Cnhy6eCqcwp2HMDdsXF2XsrHIU/TEEnb7JXX5uwSbUE=",
      "url": "_framework/System.Runtime.CompilerServices.Unsafe.yez32o001z.wasm"
    },
    {
      "hash": "sha256-23/N7P7qAdJ4cnbH0KUzi6375dR8E5qcBVZzT7EybQI=",
      "url": "_framework/System.Runtime.Extensions.jeto54ysep.wasm"
    },
    {
      "hash": "sha256-UuWzJnZzY9xQLkn+mrNbsRrwyd81DGWi8W0JOhHoKYQ=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.2g57ewosnp.wasm"
    },
    {
      "hash": "sha256-nY/HQrVvhIoTHIW0IiIijNY+Bt3NtyD3VxqJsTth8iA=",
      "url": "_framework/System.Runtime.InteropServices.RuntimeInformation.xn8nw9epod.wasm"
    },
    {
      "hash": "sha256-AgS/rXCmw7/2othAanvWvjyI2tBSSqsgjKtcwrDFNR8=",
      "url": "_framework/System.Runtime.InteropServices.eco7lofw0i.wasm"
    },
    {
      "hash": "sha256-fCErK2/BQg6FRPRhkxndy0WqMaqhdyfNIu7yIfUJtO0=",
      "url": "_framework/System.Runtime.Numerics.09g9wl94ev.wasm"
    },
    {
      "hash": "sha256-zhhtIQFvOeCBWhNlAnFOyaa+k9kdFo0pZRM6F7WmUjU=",
      "url": "_framework/System.Runtime.aqoo09dfoc.wasm"
    },
    {
      "hash": "sha256-U5qHzAnCIU/LnTasVpLVqN644SUw7CeDLwVciEhXLB8=",
      "url": "_framework/System.Security.Cryptography.tc6a3d7ut2.wasm"
    },
    {
      "hash": "sha256-J9Dql/M4bGzvzKFvTEG4VbH03ZLP3CmgnjaNzGb8DIs=",
      "url": "_framework/System.Text.Encodings.Web.1ypetucuor.wasm"
    },
    {
      "hash": "sha256-f5W2hyPhOGQ9b9jwwsVqWyoeHfmLQIf+DYWFwLpQIiM=",
      "url": "_framework/System.Text.Json.na0kbz0g60.wasm"
    },
    {
      "hash": "sha256-5M1d/7RZzvJXDqvYObpIaCM4tJa0Tr0QT1f58i/bdPI=",
      "url": "_framework/System.Text.RegularExpressions.4g6lqk94b9.wasm"
    },
    {
      "hash": "sha256-dnM4c2FG4y0DB1IGD8Bi6gAF0VIt4mVM3uNOX9Fjan4=",
      "url": "_framework/System.Threading.6sk9edg6uj.wasm"
    },
    {
      "hash": "sha256-ttX8C5GWMDoxUicDNCvKcaZ1/hvxHqy0aMzmwUtdjxU=",
      "url": "_framework/System.Web.HttpUtility.mwepifluix.wasm"
    },
    {
      "hash": "sha256-SadbI6GYTXw7kHrIi4GlY7FN4lwLNLpROb7GWs6KOFM=",
      "url": "_framework/System.Xml.Linq.l1dhntk8qt.wasm"
    },
    {
      "hash": "sha256-Sd3s9Vn4Uscsky7aa9pkHZrTKzPZT0ckLQ5cMvbAis0=",
      "url": "_framework/System.l5g27qddaj.wasm"
    },
    {
      "hash": "sha256-vbVcfNICw1riGPEoae6NO5Kwr7E9ChJXlpOGbBiNJ44=",
      "url": "_framework/UnizaScheduleApi.ruv4wsk2ow.wasm"
    },
    {
      "hash": "sha256-kcHj70iVb99s+tukDOj/jasCtDI/LBUITJ2PDPICego=",
      "url": "_framework/UnizaScheduleTable.l3tt94dylo.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-tiZJhVYL70c7t86gT2D/04c42X91ZcE1rXuBhOO23Qc=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-07As8ES9Gfy45tXxyd9HeGZ/Kq7RIPqYfJkr7h5dn0c=",
      "url": "_framework/dotnet.native.d0y0jwn3qi.js"
    },
    {
      "hash": "sha256-a4lq5NeeAj6pctkGhFvNJes975GwE51G2hCTwClgHYc=",
      "url": "_framework/dotnet.native.htf26x1fqr.wasm"
    },
    {
      "hash": "sha256-yJvgPPUUvavYVmu9VD/fYtMcoEnLVaB0Cr7JAE29btw=",
      "url": "_framework/dotnet.runtime.o0qy896u8v.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-SD+CLSQ1TKFrp9lKUQK3oeCi1Zs20YW1EydKN/a/rT4=",
      "url": "_framework/netstandard.was827on1n.wasm"
    },
    {
      "hash": "sha256-2RmJypat+qfxwZjruog7wgE6zxq7G79s0lk7r/HMtAQ=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-z8OR40MowJ8GgK6P89Y+hiJK5+cclzFHzLhFQLL92bg=",
      "url": "css/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-gBwg2tmA0Ci2u54gMF1jNCVku6vznarkLS6D76htNNQ=",
      "url": "css/bootstrap/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-rT4FH5+oxTvFqLsgN7KD+p7hVdmuum5ntNwjbKuGwJg=",
      "url": "index.html"
    },
    {
      "hash": "sha256-+KfKAgID604Cz48JSPVzAr/ALZIYAM6qYr0Txa6AUBs=",
      "url": "js/service-worker-interop.js"
    },
    {
      "hash": "sha256-DYKnOC5Czz0kD35D1nPhOlmGjZk3OBcOo3+Mfb6BmAU=",
      "url": "manifest.webmanifest"
    }
  ]
};
